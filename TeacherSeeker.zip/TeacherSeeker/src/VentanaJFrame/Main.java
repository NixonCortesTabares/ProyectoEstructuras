package VentanaJFrame;

public class Main {

	public static void main(String[] args) {
		
		MiVentana miVentana = new MiVentana();
		}
}
