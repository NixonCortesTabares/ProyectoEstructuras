package VentanaJFrame;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class MiVentana extends JFrame {

	public JComboBox<String> listaSemestres;
	public JComboBox<String> MateriasPorSemestre;
	public JLabel texto1 = new JLabel();
	public JButton botonAnadir = new JButton();
	public JButton botonEliminar = new JButton();
	public JButton botonConfirmar = new JButton();
	public JLabel texto2 = new JLabel();
	public ArrayList<String> listaActualizadora = new ArrayList<String>();
	public DefaultListModel<String> lista = new DefaultListModel();
	public JList<String> listaMaterias = new JList(lista);
	public JScrollPane scrolleador = new JScrollPane(listaMaterias);
	public Grafo_Matriz_Adyacencia grafoNuevo;
	public String[] Semestres = { "Semestre 1", "Semestre 2", "Semestre 3", "Semestre 4", "Semestre 5", "Semestre 6",
			"Semestre 7", "Semestre 8", "Semestre 9", "Semestre 10" };
	public String[][] Materias = {
			{ "Calculo I", "Fundamentos de Programacion", "Cultura Fisica", "Algebra Lineal I", "Taller de Lenguaje",
					"Quimica Basica" },	
			{ "Calculo II", "Etica Ciudadana", "Fisica I", "Programacion Orientada a Objetos",
					"Biologia para Ingenieros", "Ingles I" },
			{ "Calculo III", "Fisica II", "Matematicas Discretas", "Estructuras de Datos y Analisis de Algoritmos",
					"Ingles II" },
			{ "Ecuaciones Diferenciales", "Fisica III", "Electricidad y Electronica", "Automatas y Lenguajes Formales",
					"Base de Datos I" },
			{ "Base de Datos II", "Sistemas Digitales", "Analisis Numerico I", "Pensamiento Sistemico y Organizacional",
					"Direccion Empresarial" },
			{ "Estadistica I", "Redes de Computadores I", "Arquitectura de Computadores", "Programacion en la Web",
					"Sistemas de Informacion" },
			{ "Estadistica II", "Ingenieria de Software I", "Redes de Computadores II", "Inteligencia Artificial I" },
			{ "Sistemas Operacionales", "Ingenieria de Software II", "Simulacion Digital" },
			{ "Trabajo de Grado I", "Ingenieria Economica" }, { "Trabajo de Grado II", "Economia Empresarial" } };

	public MiVentana() {
		configurarVentana(); // Configurar la ventana principal
		inicializarComponentes(); // Inicializar los componentes de la interfaz
		agregarEventos(); // Configurar los eventos
		setVisible(true); // Mostrar la ventana
	}

	// Método para configurar la ventana
	private void configurarVentana() {
		setTitle("TeacherSeeker");
		setSize(500, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(null);
		getContentPane().setBackground(Color.WHITE);
	}

	// Método para inicializar los componentes
	public void inicializarComponentes() {
		// Listas
		listaSemestres = new JComboBox<>(Semestres);
		MateriasPorSemestre = new JComboBox<>();

		listaSemestres.setBounds(50, 60, 150, 30);
		listaSemestres.setBackground(Color.WHITE);
		listaSemestres.setBorder(new RoundBorder(5));
		MateriasPorSemestre.setBounds(220, 60, 210, 30);
		MateriasPorSemestre.setBackground(Color.WHITE);
		MateriasPorSemestre.setBorder(new RoundBorder(5));
		// Texto Guia
		texto1.setText("Por favor selecciona las asignaturas que matriculaste este semestre");
		texto1.setBounds(50, 15, 400, 30);
		// Texto 2
		texto2.setText("Las materias seleccionadas son:");
		texto2.setBounds(50, 140, 200, 30);
		// Boton Anadir
		botonAnadir.setText("Añadir asignatura");
		botonAnadir.setBounds(170, 100, 180, 30);
		botonAnadir.setBackground(Color.WHITE);
		botonAnadir.setBorder(new RoundBorder(10));
		// Boton Eliminar
		botonEliminar.setText("Eliminar");
		botonEliminar.setBounds(100, 330, 120, 30);
		botonEliminar.setBackground(Color.WHITE);
		botonEliminar.setBorder(new RoundBorder(10));
		// Boton Confirmar
		botonConfirmar.setText("Confirmar");
		botonConfirmar.setBounds(240, 330, 120, 30);
		botonConfirmar.setBackground(Color.WHITE);
		botonConfirmar.setBorder(new RoundBorder(10));
		// Lista
		scrolleador.setBounds(150, 190, 220, 100);

		// Inicializar la segunda lista con las materias del primer semestre
		actualizarMaterias(0);

		///////////////////////////////////////////// ANADIR COMPONENTES A LA VENTANA

		add(listaSemestres); // anadir lista de semestres
		add(MateriasPorSemestre); // anadir lista de asignaturas
		add(texto1); // anadir texto guia
		add(texto2);
		add(botonAnadir); // anadir boton Anadir
		add(scrolleador); // anadir lista de materias
		add(botonEliminar);
		add(botonConfirmar);
	}

	// Método para agregar los listeners a los objetos de la ventana
	public void agregarEventos() {
		listaSemestres.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int indiceSeleccionado = listaSemestres.getSelectedIndex();
				actualizarMaterias(indiceSeleccionado);
			}
		});

		botonAnadir.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String itemSeleccionado = (String) MateriasPorSemestre.getSelectedItem();

				// Verificar si el elemento ya está en la lista
				boolean existe = false;
				for (int i = 0; i < lista.getSize(); i++) {
					if (lista.getElementAt(i).equals(itemSeleccionado)) {
						existe = true;
						break;
					}
				}

				// Si no existe, agregarlo a la lista
				if (!existe) {
					lista.addElement(itemSeleccionado);
				} else {
					JOptionPane.showMessageDialog(null, "Esta materia ya ha sido agregada.", "Advertencia",
							JOptionPane.WARNING_MESSAGE);
				}
			}
		});

		botonEliminar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// Obtener el índice del elemento seleccionado
				int indiceSeleccionado = listaMaterias.getSelectedIndex();

				// Verificar si hay un elemento seleccionado
				if (indiceSeleccionado != -1) {
					// Eliminar el elemento del modelo
					lista.remove(indiceSeleccionado);
				} else {
					// Mostrar un mensaje de advertencia si no hay selección
					JOptionPane.showMessageDialog(null, "Por favor selecciona una materia para eliminar.",
							"Advertencia", JOptionPane.WARNING_MESSAGE);
				}
			}
		});

		botonConfirmar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				grafoNuevo = new Grafo_Matriz_Adyacencia(lista.size() + 1);
				for(int i = 0; i < lista.size(); i++) {
					String nombreAsignatura = lista.getElementAt(i);
					grafoNuevo.agregarNombreNodo(i, nombreAsignatura);
					
					
				}
			}
		});

	}

	// Método para actualizar las materias en función del semestre seleccionado
	public void actualizarMaterias(int indice) {
		MateriasPorSemestre.removeAllItems(); // Limpiar la lista
		for (String materia : Materias[indice]) {
			MateriasPorSemestre.addItem(materia);
		}
	}
	
}
