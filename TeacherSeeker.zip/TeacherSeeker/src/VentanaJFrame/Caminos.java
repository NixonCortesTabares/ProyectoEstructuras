package VentanaJFrame;

import java.util.ArrayList;
public class Caminos {

	public void ArraysProfesores() {
	ArrayList<String> CalculoI = new ArrayList<String>();
	ArrayList<String> CalculoII = new ArrayList<String>();
	ArrayList<String> CalculoIII = new ArrayList<String>();
	ArrayList<String> Diferenciales = new ArrayList<String>();

	CalculoI.add("Miguelito lirur");
	
	}
	
}


//- Santiago ArrayLIST
//- Nixon Jframe Votaciones
//- Camilo Grafo Graficamente.
//- Diego Creando el codigo para buscar el camino mas pesado *Tiene que ser para un grafo dirigido*.