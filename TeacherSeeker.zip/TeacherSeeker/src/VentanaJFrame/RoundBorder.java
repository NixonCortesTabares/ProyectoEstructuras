package VentanaJFrame;
import javax.swing.*;
import javax.swing.border.Border;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RoundBorder implements Border{
        private int radio;

        public RoundBorder(int radio) {
            this.radio = radio;
        }

     
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            g.setColor(Color.BLACK); // Color del borde
            g.drawRoundRect(x, y, width - 1, height - 1, radio, radio);
        }

        
        public Insets getBorderInsets(Component c) {
            return new Insets(radio + 1, radio + 1, radio + 1, radio + 1);
        }

     
        public boolean isBorderOpaque() {
            return true;
        }
    }

