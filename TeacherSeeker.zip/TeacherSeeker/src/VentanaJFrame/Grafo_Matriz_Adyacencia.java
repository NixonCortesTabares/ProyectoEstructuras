package VentanaJFrame;

import java.util.ArrayList;
import java.util.List;

public class Grafo_Matriz_Adyacencia {
	public int V; // Número de nodos (materias)
	public int A; // Número de aristas (profesores)
	public String[] nombreNodos; // Arreglo para los nombres de las materias
	public List<Arista>[][] matrizAdyacencia; // Matriz de listas de aristas

	// Constructor
	public Grafo_Matriz_Adyacencia(int nodos) {
		this.V = nodos;
		this.A = 0;
		this.nombreNodos = new String[nodos];
		this.matrizAdyacencia = new ArrayList[nodos][nodos];

		for (int i = 0; i < nodos; i++) {
			for (int j = 0; j < nodos; j++) {
				matrizAdyacencia[i][j] = new ArrayList<>();
			}
		}
	}

	public void agregarNombreNodo(int nodo, String nombre) {
		if (nodo >= 0 && nodo < V) {
			nombreNodos[nodo] = nombre;

		}
	}

	public void agregarArista(int u, int v, String nombre_profesor, int valor) {

		matrizAdyacencia[u][v].add(new Arista(valor, nombre_profesor));
		A++;
	}

	public void imprimirMatriz() {

		for (int i = 0; i < V; i++) {
			System.out.println("Materia: " + nombreNodos[i] + " ->");
			for (int j = 0; j < V; j++) {
				if (!matrizAdyacencia[i][j].isEmpty()) {
					System.out.print(nombreNodos[j] + ": ");
					for (Arista arista : matrizAdyacencia[i][j]) {
						System.out.print(arista + " ");
					}
					System.out.println();
				}
			}
		}
	}
}
