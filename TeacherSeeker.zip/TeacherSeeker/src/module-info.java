/**
 * 
 */
/**
 * 
 */
module TeacherSeeker {
	requires java.desktop;
}